﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret= "IviGXE18hNakC9i4aOIGdQeWAVJZ1wDvbuLa12IF",
            BasePath= "https://testlilylisa.firebaseio.com/"
        };

        IFirebaseClient client;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);
            
        }

        private async void btnsave_Click(object sender, EventArgs e) // บันทึกข้อมูลไปยัง Database
        {
            var student = new Student
            {
                id=txtid.Text,
                fname=txtfname.Text,
                lname=txtlname.Text
            };

            SetResponse response = await client.SetTaskAsync("Student/"+txtid.Text,student); //path ที่ต้องการ
            clearTextbox();
        }

        void clearTextbox()
        {
            txtid.Text = "";
            txtfname.Text = "";
            txtlname.Text = "";
        }

        private async void bntSearch_Click(object sender, EventArgs e)  // ค้นหาข้อมูลใน Database
        {
            FirebaseResponse response = await client.GetTaskAsync("Student/"+txtsearch.Text);
            Student stu = response.ResultAs<Student>(); // ดึงข้อมูลมาเก็บไว้ใน object
            // นำข้อมูลที่ได้มา set
            txtid.Text = stu.id;
            txtfname.Text = stu.fname;
            txtlname.Text = stu.lname;
        }
    }
}
