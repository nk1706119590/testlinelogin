﻿namespace WindowsFormsApp1
{
    internal class Student
    {
        public string id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
    }
}